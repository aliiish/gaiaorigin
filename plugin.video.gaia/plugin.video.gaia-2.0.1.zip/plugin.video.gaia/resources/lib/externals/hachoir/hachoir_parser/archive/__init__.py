from resources.lib.externals.hachoir.hachoir_parser.archive.ace import AceFile
from resources.lib.externals.hachoir.hachoir_parser.archive.ar import ArchiveFile
from resources.lib.externals.hachoir.hachoir_parser.archive.bzip2_parser import Bzip2Parser
from resources.lib.externals.hachoir.hachoir_parser.archive.cab import CabFile
from resources.lib.externals.hachoir.hachoir_parser.archive.gzip_parser import GzipParser
from resources.lib.externals.hachoir.hachoir_parser.archive.tar import TarFile
from resources.lib.externals.hachoir.hachoir_parser.archive.zip import ZipFile
from resources.lib.externals.hachoir.hachoir_parser.archive.rar import RarFile
from resources.lib.externals.hachoir.hachoir_parser.archive.rpm import RpmFile
from resources.lib.externals.hachoir.hachoir_parser.archive.sevenzip import SevenZipParser
from resources.lib.externals.hachoir.hachoir_parser.archive.mar import MarFile

