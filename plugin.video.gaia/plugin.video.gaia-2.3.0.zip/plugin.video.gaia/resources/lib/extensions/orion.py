# -*- coding: utf-8 -*-

'''
	Gaia Add-on
	Copyright (C) 2016 Gaia

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import threading
from resources.lib.extensions import tools
from resources.lib.extensions import network
from resources.lib.extensions import interface
from resources.lib.extensions import metadata

class Orion(object):

	Name = 'Orion'

	# NB Must end with /
	Link = 'https://api.orionoid.com' #tools.Settings.getString('link.api', raw = True) # gaiaremove

	KeyApp = '00000000000000000000000000000000' # gaiaremove
	KeyUser = None # gaiaremove

	IgnoreExcludes = ['alluc', 'alluc.ee', 'prontv', 'pron.tv', 'llucy', 'llucy.net']

	ParameterMode = 'mode'
	ParameterAction = 'action'
	ParameterKeyApp = 'keyapp'
	ParameterKeyUser = 'keyuser'
	ParameterResult = 'result'
	ParameterQuery = 'query'
	ParameterStatus = 'status'
	ParameterType = 'type'
	ParameterDescription = 'description'
	ParameterMessage = 'message'
	ParameterData = 'data'

	StatusUnknown = 'unknown'
	StatusBusy = 'busy'
	StatusSuccess = 'success'
	StatusError = 'error'

	ModeStream = 'stream'
	ModeUser = 'user'

	ActionUpdate = 'update'
	ActionRetrieve = 'retrieve'

	TypeMovie = 'movie'
	TypeShow = 'show'

	StreamTorrent = 'torrent'
	StreamUsenet = 'usenet'
	StreamHoster = 'hoster'

	AudioStandard = 'standard'
	AudioDubbed = 'dubbed'

	SubtitleSoft = 'soft'
	SubtitleHard = 'hard'

	##############################################################################
	# CONSTRUCTOR
	##############################################################################

	def __init__(self):
		self.mApiStatus = None
		self.mApiType = None
		self.mApiDescription = None
		self.mApiMessage = None
		self.mApiData = None

	##############################################################################
	# ENABLED
	##############################################################################

	def enabled(self):
		return True # gaiaremove - if an orion account is enabled

	##############################################################################
	# API
	##############################################################################

	def _apiRequest(self, mode = None, action = None, parameters = {}):
		self.mApiStatus = None
		self.mApiType = None
		self.mApiDescription = None
		self.mApiMessage = None
		self.mApiData = None

		if not mode == None: parameters[self.ParameterMode] = mode
		if not action == None: parameters[self.ParameterAction] = action

		parameters[self.ParameterKeyApp] = self.KeyApp
		if self.KeyUser: parameters[self.ParameterKeyUser] = self.KeyUser

		try:
			data = network.Networker(link = self.Link, parameters = parameters, debug = self.enabled()).retrieve(addon = True)
			data = tools.Converter.jsonFrom(data)

			result = data[self.ParameterResult]
			if self.ParameterStatus in result: self.mApiStatus = result[self.ParameterStatus]
			if self.ParameterType in result: self.mApiType = result[self.ParameterType]
			if self.ParameterDescription in result: self.mApiDescription = result[self.ParameterDescription]
			if self.ParameterMessage in result: self.mApiMessage = result[self.ParameterMessage]
			if self.ParameterData in result: self.mApiData = result[self.ParameterData]

			if self.enabled() and self.mApiStatus == self.StatusError:
				title = self.Name + ' - ' + str(self.mApiDescription)
				interface.Dialog.notification(title = title, titleless = True, message = self.mApiMessage, icon = interface.Dialog.IconError, time = 5000)

			return self.mApiData
		except:
			if self.enabled(): tools.Logger.error('Orion API Error')
			return None

	##############################################################################
	# API - STATUS
	##############################################################################

	def apiStatus(self):
		return self.mApiStatus

	def apiStatusHas(self):
		return not self.mApiStatus == None

	def apiStatusSuccess(self):
		return self.mApiStatus == self.StatusSuccess

	def apiStatusError(self):
		return self.mApiStatus == self.StatusError

	##############################################################################
	# API - TYPE
	##############################################################################

	def apiType(self):
		return self.mApiType

	def apiTypeHas(self):
		return not self.mApiType == None

	##############################################################################
	# API - DESCRIPTION
	##############################################################################

	def apiDescription(self):
		return self.mApiDescription

	def apiDescriptionHas(self):
		return not self.mApiDescription == None

	##############################################################################
	# API - MESSAGE
	##############################################################################

	def apiMessage(self):
		return self.mApiMessage

	def apiMessageHas(self):
		return not self.mApiMessage == None

	##############################################################################
	# API - DATA
	##############################################################################

	def apiData(self):
		return self.mApiData

	def apiDataHas(self):
		return not self.mApiData == None

	##############################################################################
	# STREAMS - UPDATE
	##############################################################################

	def _streamIgnore(self, stream):
		try:
			# Streams retrieved from Orion
			if 'orion' in stream and stream['orion']: return True

			# Local stream
			if 'local' in stream and stream['local']: return True

			# Member and premium streams
			if 'memberonly' in stream and stream['memberonly']:
				excluded = False
				for exclude in self.IgnoreExcludes:
					if ('id' in stream and exclude in stream['id'].lower()) or ('name' in stream and exclude in stream['name'].lower()) or ('provider' in stream and exclude in stream['provider'].lower()) or ('source' in stream and exclude in stream['source'].lower()):
						excluded = True
						break
				if not excluded: return True

			# Not magnet and not http/ftp
			if not network.Networker.linkIs(stream['url']) and not network.Container(stream['url']).torrentIsMagnet(): return True

			# Streams with cookies and headers
			if '|' in stream['url']: return True
		except:
			return True
		return False

	def _streamUpdate(self, meta, streams):
		item = self._streamUpdateMeta(meta)
		item['streams'] = []
		for stream in streams:
			if not self._streamIgnore(stream):
				data = {'stream' : {}, 'cached' : {}, 'file' : {}, 'meta' : {}, 'video' : {}, 'audio' : {}, 'subtitle' : {}}
				meta = metadata.Metadata.initialize(stream)

				provider = stream['provider']
				providerLower = provider.lower()
				if providerLower.startswith('inc-') or providerLower.startswith('pla-') or providerLower.startswith('uni-') or providerLower.startswith('nan-'):
					provider = provider[4:]

				if stream['source'] == self.StreamTorrent: data['stream']['type'] = self.StreamTorrent
				elif stream['source'] == self.StreamUsenet: data['stream']['type'] = self.StreamUsenet
				else: data['stream']['type'] = self.StreamHoster

				data['stream']['link'] = stream['url']
				data['stream']['source'] = provider
				data['stream']['direct'] = meta.direct()
				if meta.seeds() > 0: data['stream']['seeds'] = meta.seeds()
				if meta.age() > 0: data['stream']['time'] = tools.Time.timestamp() - (meta.age() * 86400)

				if 'cache' in stream:
					if 'premiumize' in stream['cache']: data['cached']['premiumize'] = stream['cache']['premiumize']
					if 'offcloud' in stream['cache']: data['cached']['offcloud'] = stream['cache']['offcloud']
					if 'realdebrid' in stream['cache']: data['cached']['realdebrid'] = stream['cache']['realdebrid']

				if 'hash' in stream: data['file']['hash'] = stream['hash']
				if 'file' in stream: data['file']['name'] = stream['file']
				if meta.size(False, True) > 0: data['file']['size'] = meta.size(False, True)
				data['file']['pack'] = meta.pack()

				if meta.release(False): data['meta']['release'] = meta.release(False)
				if meta.uploader(False): data['meta']['uploader'] = meta.uploader(False)
				if meta.edition(): data['meta']['edition'] = meta.edition()

				if meta.videoQuality(): data['video']['quality'] = meta.videoQuality()
				if meta.videoCodec(): data['video']['codec'] = meta.videoCodec()
				data['video']['3d'] = meta.videoExtra3d()

				if meta.videoQuality(): data['video']['quality'] = meta.videoQuality()
				if meta.videoCodec(): data['video']['codec'] = meta.videoCodec()
				data['video']['3d'] = meta.videoExtra3d()

				data['audio']['type'] = self.AudioDubbed if meta.audioDubbed() else self.AudioStandard
				data['audio']['channels'] = meta.audioChannels(True) if meta.audioChannels(True) else 2
				if meta.audioCodec(): data['audio']['codec'] = meta.audioCodec()
				data['audio']['languages'] = [i[0] for i in meta.audioLanguages()] if len(meta.audioLanguages()) > 0 else [tools.Language.EnglishCode]

				if meta.subtitlesIsSoft() or meta.subtitlesIsHard(): data['subtitle']['type'] = self.SubtitleHard if meta.subtitlesIsHard() else self.SubtitleSoft

				item['streams'].append(data)
		self._apiRequest(mode = self.ModeStream, action = self.ActionUpdate, parameters = {self.ParameterData : item})

	def _streamUpdateMeta(self, meta):
		item = {}
		item['type'] = self.TypeShow if 'tvshowtitle' in meta else self.TypeMovie

		item['id'] = {}
		if 'imdb' in meta: item['id']['imdb'] = meta['imdb'].replace('tt', '')
		if 'tmdb' in meta: item['id']['tmdb'] = meta['tmdb']
		if 'tvdb' in meta: item['id']['tvdb'] = meta['tvdb']

		item['meta'] = {}
		if item['type'] == self.TypeMovie:
			if 'title' in meta: item['meta']['title'] = meta['title']
			try:
				if 'year' in meta: item['meta']['year'] = int(meta['year'])
			except: pass
		else:
			item['meta']['title'] = {}
			item['meta']['title']['show'] = meta['tvshowtitle']
			if 'title' in meta: item['meta']['title']['episode'] = meta['title']
			else: item['meta']['title']['episode'] = item['meta']['title']['show']

			item['meta']['year'] = {}
			try:
				if 'tvshowyear' in meta: item['meta']['year']['show'] = int(meta['tvshowyear'])
				elif 'year' in meta: item['meta']['year']['show'] = int(meta['year'])
			except: pass
			try:
				if 'year' in meta: item['meta']['year']['episode'] = int(meta['year'])
				elif 'tvshowyear' in meta: item['meta']['year']['episode'] = int(meta['tvshowyear'])
			except: pass

			item['number'] = {}
			season = str(meta['season']).lower().replace('season', '').replace(' ', '')
			try: item['number']['season'] = int(season)
			except:
				try: item['number']['season'] = tools.Converter.roman(season)
				except: pass
			episode = str(meta['episode']).lower().replace('episode', '').replace(' ', '')
			try: item['number']['episode'] = int(episode)
			except:
				try: item['number']['episode'] = tools.Converter.roman(episode)
				except: pass

		return item

	def streamUpdate(self, meta, streams, wait = False):
		thread = threading.Thread(target = self._streamUpdate, args = (meta, streams))
		thread.start()
		if wait:
			thread.join()
			return self.apiStatusSuccess()
		else:
			return self.StatusBusy
